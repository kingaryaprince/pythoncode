##import simplemath
##num1 = int(input("Number 1: "))
##num2 = int(input("Number 2: "))
##num3 = int(input("Number 3: "))
##num4 = int(input("Number 4: "))
##num5 = int(input("Number 5: "))
##x = simplemath.add(num1,num2)
##print(x)
##x = simplemath.subtract(x,num3)
##print(x)
##x = simplemath.divide(x,num4)
##print(x)
##x = simplemath.multiply(x,num5)
##print(x)



##for x in range(1,4,1):
##    print("*"*x)
##for x in range(2,0,-1):
##    print("*"*x)

##import time
##x = 0
##y = 0
##while True:
##    x= x+y
##    print(x)
##    time.sleep(1)
##    if x == 10:
##        y = -1
##    elif x == 0:
##        y = 1

##question = None
##while question != "Yes":
##    question = input("Do you want to quit [ Say Yes to quit ]: ")

##L = ["burger", "chips", "french fries", "soda"]
##L.append("pancake")
##L.insert(3,"hot dog")
##L.pop()
##L.pop(2)
##L.remove("chips")
##L.reverse()
##L.sort()
##print(L[1])
##print(L)
##L[2] = "food"
##print(L)

##L = []
##import random
##for x in range(1,6,1):
##    L.append(random.randint(0,100))
##print(L)
##


##Review While loops
##Next week - Functions and dictionaries
