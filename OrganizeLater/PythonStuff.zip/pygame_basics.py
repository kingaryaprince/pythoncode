import pygame
from pygame.locals import *
pygame.init()
import time
import random
clock = pygame.time.Clock()
