def addfunc(x,y):
    return x+y
def subtractfunc(x,y):
    return x-y
def multiplyfunc(x,y):
    return x*y
def dividefunc(x,y):
    return x/y
