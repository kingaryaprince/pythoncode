##a = int(input(' What is your age '))
##a += 25
##print('Your age in 25 years is '+ str(a))

a = 'pizza'
b = 'pasta'
print(a)
print(b)
c = b
d = a
a = c
b = d
print(a)
print(b)
