
##a = int(input('What number factorial do you want: '))
##c= 1
##for i in range(1,a+1):
##    c = c *i
##print(c)

##a =   int(input('type in number 1: '))
##b = int(input('type in number 2: '))
##
##neg_pos = None
##if a>b:
##    neg_pos = -1
##else:
##    neg_pos = +1
##for i in range(a,neg_pos+b,neg_pos):
##    print(i)

##1 1 2 3 5 8 13
b = 1
c = 0
d = 0
for a in range(1,8):
    print(b)

    d = b + c
    c = b
    b = d
    
    
    
    

    
    

