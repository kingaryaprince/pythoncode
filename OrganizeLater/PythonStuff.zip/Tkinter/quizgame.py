from tkinter import *

root=Tk()
root.title("Quiz Game")

class Question():
    def __init__(self, question, options, answer, answer_index):
        self.question = question
        self.options = options
        self.answer = answer
        self.answer_index = answer_index
question1 = Question("What is 2 + 2?", ["2","3","4","5"], "4", 2)
question2 = Question("What color is an apple usually?", ["Red","Green","Purple","Blue"], "Red", 0)
question3 = Question("What is 7 + 3?", ["27","10","6","13"], "10", 1)

question_list = [question1, question2, question3]
option_list = []
x = question_list[0].question
y = question_list[0].options
z = question_list[0].answer


def submit():
    print("submit")
    if answer.get() == question_list[0].answer:
        print("correct")
    else:
        print("wrong")

def next_frame():
    print("next")

frame1 = Frame(root)
frame2 = Frame(root)
frame3 = Frame(root)
frame1.pack()
frame2.pack()
frame3.pack()  


#Label
score_label = Label(frame1,text = "Score = x")
score_label.grid(row = 0, column = 0,columnspan=4)

question_label = Label(frame2, text = x)
question_label.pack()

answer = StringVar()
answer.set(None) 
for x in question_list[0].options:
    option = Radiobutton(frame2, variable = answer, text= x, value=x)
    option_list.append(option)
    option.pack()





#Entry Box
#user_entry = Entry(root)
#user_entry.grid(row = 0, column = 1) 





#Button
submit_button = Button(frame3, text = "Submit", command = submit)
submit_button.grid(row = 6, column=0)

next_button = Button(frame3, text = "Next", command = next_frame)
next_button.grid(row = 6, column = 4) 



    



root.mainloop()

#