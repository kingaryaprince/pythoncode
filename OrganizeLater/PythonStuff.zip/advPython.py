##t1 = 0
##t2 = 1
##number = 0
##for x in range(0,15,1):
##    number = t1+t2
##    t1 = t2
##    t2 = number
##    print(number)


number = 9
for y in range(0,10,2):
    print()
    for x in range(0,y,2):
        print(number-x, end = " ")
        
